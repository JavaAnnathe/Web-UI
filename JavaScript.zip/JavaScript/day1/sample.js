function simple()
{

alert("This is an example of function");

}
