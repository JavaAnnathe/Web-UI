const posts=[
{title:'one',body:'it is post one'},
{title:'two',body:'it is post two'}
]

function createPost(post,callback){
setTimeout(()=>{
posts.push(post);
callback();},2000);
}




function getPosts(){
	setTimeout(()=>{
let output='';
posts.forEach((post,index)=>{
	output+=`<li>${post.title}</li>`;
},1000);
document.body.innerHTML=output;
});

}

createPost({title:'three',body:'post three'},getPosts);

