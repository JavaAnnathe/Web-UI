const posts=[
{title:'one',body:'it is post one'},
{title:'two',body:'it is post two'}
];

function createPost(post){

return new Promise((resolve,reject)=>{

	setTimeout(()=>{
		posts.push(post);
		
		const error=false;

		if(!error){

			resolve();
		}else{

			reject('error');
		}

		},2000);


});
}


function getPosts(){
	setTimeout(()=>{
let output='';
posts.forEach((post,index)=>{
	output+=`<li>${post.title}</li>`;
},1000);
document.body.innerHTML=output;
});

}

createPost({title:'three',body:'post three'}).then(getPosts()).catch(err=>console.log(err))

